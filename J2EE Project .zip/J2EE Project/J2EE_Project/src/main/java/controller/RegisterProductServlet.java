package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbHelper.ProductQuery;

/**
 * Servlet implementation class RegisterProductServlet
 */
@WebServlet("/RegisterProductServlet")
public class RegisterProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterProductServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("In RegisterProductServlet - Post...");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String css = "<link rel='stylesheet' type='text/css'>";
		String docType = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 " + "Transitional//EN\">\n";
		boolean isValid = true;

		String username = request.getParameter("username");
		String productName = request.getParameter("productName");
		String productSerialNum = request.getParameter("productSerialNum");
		String purchaseDate = request.getParameter("purchaseDate");

		if (username.isEmpty() || productName.isEmpty() || productSerialNum.isEmpty() || purchaseDate.isEmpty()) {
			out.println(
					"<H3 style='color:red;'>*Please go back, and enter all the details to register a product.*</H3>");
			isValid = false;
		}

		if (isValid) {
	        try {
	            ProductQuery pQ = new ProductQuery();

	            String validationMessage = pQ.doValidateProductDetailsBeforeRegister(username,productSerialNum, productName);

	            if ("Product record exists".equals(validationMessage)) {
	                // Product is already registered
	                out.println("<H3 style='color:red;'>" + validationMessage + "</H3>");
	            } else if ("Product available for registration".equals(validationMessage)) {
	                // Product is available for registration
	                pQ.doRegisterProduct(username, productName, productSerialNum, purchaseDate);
	                request.setAttribute("loggedInUser", username);
	                RequestDispatcher dispatcher = request.getRequestDispatcher("/UserHome.jsp");
	                dispatcher.forward(request, response);
	            } else {
	                // Product not available or other validation message
	                out.println("<H3 style='color:red;'>" + validationMessage + "</H3>");
	            }

	            // Add a button to go back, displayed in all cases except successful registration
	            if (!"Product available for registration".equals(validationMessage)) {
	                out.println("<button onclick='history.back()'>Go Back</button>");
	            }

	        } catch (Exception e) {
	        	out.println("<H3 style='color:red;'>An error occurred: " + e.getMessage() + "</H3>");
	            }
	    } else {
	        // Handle case where input validation fails
	        out.println("<H3 style='color:red;'>Please go back and enter all the required details.</H3>");
	        out.println("<button onclick='history.back()'>Go Back</button>");
	    }
	}

}

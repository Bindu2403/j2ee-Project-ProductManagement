package filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter("/*")
public class AuthenitcationFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code, if needed
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        String requestURI = httpRequest.getRequestURI();

        if (requestURI.endsWith("menu.html") || requestURI.endsWith("add_food.html") || requestURI.endsWith("add_user.html") || requestURI.endsWith("reservations.html")) {
            // Get the session
            HttpSession session = httpRequest.getSession(false);

            // Check if the user is authenticated
            if (session == null || session.getAttribute("authenticated") == null || !((boolean) session.getAttribute("authenticated"))) {
                // User is not authenticated, redirect to the login page
                httpResponse.sendRedirect("index.html");
                return; // Stop further processing
            }
        }

        // Continue processing the request
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Cleanup code, if needed
    }
}